import { NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';
import { adminDb } from '@/app/lib/firebaseAdmin';
import { FALLBACK_REBUTTALS, FALLBACK_SIMULATIONS, isBlockedCountryName } from '@/app/lib/constants';
import { FieldValue } from 'firebase-admin/firestore';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function POST(req: Request) {
  try {
    const db = adminDb();
    const { action, code, groupId, payload } = await req.json();

    const sessionRef = db.collection('sessions').doc(code);
    const groupRef = sessionRef.collection('groups').doc(String(groupId));
    const [sessionSnap, groupSnap] = await Promise.all([sessionRef.get(), groupRef.get()]);

    if (!sessionSnap.exists || !groupSnap.exists) {
      return NextResponse.json({ error: '세션 또는 모둠 정보를 찾을 수 없습니다.' }, { status: 404 });
    }

    const sessionData = sessionSnap.data()!;
    const groupData = groupSnap.data()!;
    const countryName = groupData.country?.name || '우리나라';
    const fallbackMode = sessionData.teacherSettings?.fallbackMode || false;
    const textModel = process.env.GEMINI_TEXT_MODEL || 'gemini-2.5-flash';

    // --- 1. S3.5 AI 반론 생성 ---
    if (action === 'GENERATE_REBUTTAL') {
      const { policy, reason, theory } = payload;

      if (isBlockedCountryName(reason)) {
        return NextResponse.json({ error: '이유에 실제 국가명(한국, 미국, 중국 등)이 들어있습니다. 가상 이름(아메리카나 연방, 중원 공화국, 자유항)만 써주세요.' }, { status: 400 });
      }

      let rebuttalResult = FALLBACK_REBUTTALS[policy] || FALLBACK_REBUTTALS['중립 선언 및 평화 중재'];

      if (!fallbackMode && process.env.GEMINI_API_KEY) {
        try {
          const prompt = `
너는 [${countryName}]의 국가안보회의에 참석한 날카로운 외교 자문위원이다.
지금 우리 국가 [${countryName}]가 선택한 정책은 "${policy}"이고, 이유는 "${reason}"이다. (학생이 고른 성향: ${theory})

[세계관 설정 - 절대 혼동 금지]
- 우리 국가 이름: ${countryName} (반드시 우리 국가를 '${countryName}'이라고 부를 것!)
- 동맹국: 아메리카나 연방 (군사·안보 동맹국, 지원 요청 중)
- 최대 교역국: 중원 인민공화국 (우리 수출의 40% 담당, 지원 시 무역 보복 예고)
- 위기 지역: 자유항 (중원 공화국에 해상 봉쇄된 민주주의 소국)

[작성 규칙]
1. 고등학교 2학년 학생이 듣고 바로 찔릴 만큼 쉽고 직관적인 구어체로 쓸 것. 딱딱한 논문투나 AI 번역투("지속 가능한", "다각적인", "측면에서") 절대 금지!
2. 공리주의 쪽이면 "약속과 도덕적 원칙을 저버려도 되나?"를 찌르고, 의무론 쪽이면 "우리 국민 경제가 망가져도 괜찮나?"를 찌를 것.
3. 반드시 아래 순수 JSON으로만 출력:
{"rebuttal": "핵심을 찌르는 반론 2문장", "question": "학생들이 답해야 할 날카로운 질문 1문장"}
          `;
          const response = await ai.models.generateContent({ model: textModel, contents: prompt });
          const cleaned = (response.text || '').replace(/```json/g, '').replace(/```/g, '').trim();
          const parsed = JSON.parse(cleaned);
          if (parsed.rebuttal && parsed.question) {
            rebuttalResult = parsed;
          }
        } catch (err) {
          console.warn('AI 반론 생성 실패, 대체본 전환:', err);
        }
      }

      await groupRef.update({
        draft: { policy, reason, theory },
        rebuttal: rebuttalResult,
        step: 'S3.5',
        logs: FieldValue.arrayUnion({ type: 'REBUTTAL', at: new Date().toISOString(), countryName, input: { policy, theory }, output: rebuttalResult })
      });

      return NextResponse.json({ success: true, rebuttal: rebuttalResult });
    }

    // --- 2. S3.6 최종 결정 제출 -> S4 시뮬레이션 실행 ---
    if (action === 'RUN_SIMULATION') {
      const { rebuttalReply, keepOrRevise, finalPolicy, finalReason } = payload;

      let simResult = FALLBACK_SIMULATIONS[finalPolicy] || FALLBACK_SIMULATIONS['중립 선언 및 평화 중재'];

      if (!fallbackMode && process.env.GEMINI_API_KEY) {
        try {
          const prompt = `
너는 현대 국제정치 뉴스 시뮬레이터다.
국가 [${countryName}]가 최종적으로 "${finalPolicy}" 정책을 발표했다. (이유: "${finalReason}")
이 발표 직후 벌어지는 긴박한 뉴스 속보 3가지를 만들어라.

[등장 국가 - 이름 정확히 지킬 것]
- 발표 국가(우리나라): ${countryName}
- 동맹국: 아메리카나 연방
- 교역국: 중원 인민공화국
- 분쟁 지역: 자유항

[작성 규칙]
- 고등학생이 TV 뉴스 속보나 콜오브듀티 작전 브리핑을 보는 것처럼 짧고 강렬하며 이해하기 쉽게 쓸 것.
- 반드시 아래 JSON 형식으로만 출력:
{
  "ally_statement": {"speaker": "아메리카나 연방 국방부", "text": "2~3문장의 생생한 성명", "scene": "보도 사진 장면 묘사 한 줄"},
  "trade_response": {"speaker": "중원 인민공화국 상무부", "text": "2~3문장의 생생한 대응", "scene": "보도 사진 장면 묘사 한 줄"},
  "news_article": {"headline": "강렬한 뉴스 헤드라인 한 줄", "body": "2~3문장의 국내 여론 및 경제 반응 기사", "source": "아르크24 긴급뉴스", "scene": "보도 사진 장면 묘사 한 줄"},
  "ticker": ["속보 1", "속보 2"],
  "relations": {"ally": 1, "trade": -2, "conflict_tension": 2}
}
          `;
          const response = await ai.models.generateContent({ model: textModel, contents: prompt });
          const cleaned = (response.text || '').replace(/```json/g, '').replace(/```/g, '').trim();
          const parsed = JSON.parse(cleaned);

          if (parsed.ally_statement && parsed.trade_response && parsed.news_article) {
            simResult = parsed;
          }
        } catch (err) {
          console.warn('AI 시뮬레이션 생성 실패, 대체본 전환:', err);
        }
      }

      await groupRef.update({
        rebuttalReply,
        final: { policy: finalPolicy, reason: finalReason, keepOrRevise },
        simulation: simResult,
        step: 'S4',
        logs: FieldValue.arrayUnion({ type: 'SIMULATION', at: new Date().toISOString(), countryName, input: { finalPolicy }, output: simResult })
      });

      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: '잘못된 요청입니다.' }, { status: 400 });
  } catch (err: any) {
    console.error('Simulate API Error:', err);
    return NextResponse.json({ error: err.message || '시뮬레이션 처리 오류' }, { status: 500 });
  }
}