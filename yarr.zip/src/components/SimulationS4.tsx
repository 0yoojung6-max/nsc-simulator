'use client';

import React, { useState, useEffect, useRef } from 'react';

interface S4Props {
  countryName: string;
  policy: string;
  simulationData: {
    ally_statement: { speaker: string; text: string; scene?: string };
    trade_response: { speaker: string; text: string; scene?: string };
    news_article: { headline: string; body: string; source: string; scene?: string };
    ticker: string[];
    relations: { ally: number; trade: number; conflict_tension: number };
  };
  s4Control?: { command: string; speed: number; timestamp: number };
  onComplete: () => void;
}

export default function SimulationS4({ countryName, policy, simulationData, s4Control, onComplete }: S4Props) {
  // 0: 공습/긴급 경보(3초) -> 1: 장면1 동맹국(5초) -> 2: 장면2 교역국(5초) -> 3: 장면3 국내여론(5초) -> 4: 작전 브리핑 요약 및 S5 이동(18초 시점)
  const [sceneIdx, setSceneIdx] = useState<number>(0);
  const [muted, setMuted] = useState<boolean>(false); // 기본 소리 켜짐
  const audioCtxRef = useRef<AudioContext | null>(null);

  const speed = s4Control?.speed || 1;

  // 현실적인 민방위 사이렌 & 전술 무전 사운드 합성
  const playRealisticSiren = () => {
    if (muted) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const now = ctx.currentTime;

      osc.type = 'sawtooth';
      // 420Hz에서 780Hz로 실제 사이렌처럼 웅장하게 상승 후 하강
      osc.frequency.setValueAtTime(420, now);
      osc.frequency.exponentialRampToValueAtTime(780, now + 1.4);
      osc.frequency.exponentialRampToValueAtTime(440, now + 2.8);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.08, now + 0.3);
      gain.gain.linearRampToValueAtTime(0.08, now + 2.3);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 2.9);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 2.9);
    } catch (e) {
      // 브라우저 자동재생 정책 차단 시 무시
    }
  };

  const playRadioBeep = () => {
    if (muted) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const now = ctx.currentTime;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(1200, now);
      osc.frequency.setValueAtTime(1600, now + 0.08);

      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.22);
    } catch (e) {}
  };

  useEffect(() => {
    if (!s4Control) return;
    if (s4Control.command === 'SKIP') setSceneIdx(4);
    if (s4Control.command === 'REPLAY') setSceneIdx(0);
  }, [s4Control?.command, s4Control?.timestamp]);

  // 총 18초 만에 끝나는 밀도 높은 시네마틱 컷신 타임라인
  useEffect(() => {
    if (sceneIdx === 4) return;
    const k = 1 / speed;
    const timers: NodeJS.Timeout[] = [];

    if (sceneIdx === 0) {
      playRealisticSiren();
      timers.push(setTimeout(() => { setSceneIdx(1); playRadioBeep(); }, 3000 * k));
    }
    if (sceneIdx <= 1) {
      timers.push(setTimeout(() => { setSceneIdx(2); playRadioBeep(); }, 8000 * k));
    }
    if (sceneIdx <= 2) {
      timers.push(setTimeout(() => { setSceneIdx(3); playRadioBeep(); }, 13000 * k));
    }
    if (sceneIdx <= 3) {
      timers.push(setTimeout(() => { setSceneIdx(4); playRadioBeep(); }, 18000 * k));
    }

    return () => timers.forEach(clearTimeout);
  }, [sceneIdx, speed]);

  const scenes = [
    {
      code: 'CAM-01 // ALLY BRIEFING',
      badge: '동맹국 아메리카나 연방 반응',
      badgeColor: 'bg-[#34B3A8] text-[#0C1822]',
      speaker: simulationData?.ally_statement?.speaker || '아메리카나 연방 국방부',
      headline: simulationData?.ally_statement?.text,
      visualDesc: simulationData?.ally_statement?.scene || '야간 군용 활주로에서 전략 수송기가 긴급 이륙을 준비하는 모습',
      bgOverlay: 'from-[#0d2638] via-[#091622] to-black',
      svgIcon: (
        <svg viewBox="0 0 800 320" className="w-full h-full object-cover opacity-60">
          <defs>
            <radialGradient id="radar1" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#34B3A8" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#0C1822" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="800" height="320" fill="#08121a" />
          <circle cx="400" cy="160" r="140" fill="url(#radar1)" />
          <circle cx="400" cy="160" r="110" fill="none" stroke="#34B3A8" strokeWidth="1" strokeDasharray="6 6" />
          <circle cx="400" cy="160" r="65" fill="none" stroke="#34B3A8" strokeWidth="1.5" />
          <line x1="220" y1="160" x2="580" y2="160" stroke="#27404F" strokeWidth="1" />
          <line x1="400" y1="20" x2="400" y2="300" stroke="#27404F" strokeWidth="1" />
          <polygon points="400,130 420,175 400,165 380,175" fill="#34B3A8" />
        </svg>
      )
    },
    {
      code: 'CAM-02 // TRADE BLOCKADE',
      badge: '교역국 중원 인민공화국 조치',
      badgeColor: 'bg-[#E2504A] text-white',
      speaker: simulationData?.trade_response?.speaker || '중원 인민공화국 상무부',
      headline: simulationData?.trade_response?.text,
      visualDesc: simulationData?.trade_response?.scene || '해상 봉쇄선과 통제된 대형 컨테이너 항만의 긴장감 넘치는 전경',
      bgOverlay: 'from-[#381212] via-[#1f0a0a] to-black',
      svgIcon: (
        <svg viewBox="0 0 800 320" className="w-full h-full object-cover opacity-60">
          <rect width="800" height="320" fill="#140808" />
          <path d="M0 220 Q 200 190 400 220 T 800 220 L 800 320 L 0 320 Z" fill="#2b0e0e" />
          <rect x="260" y="130" width="90" height="50" fill="none" stroke="#E2504A" strokeWidth="2" />
          <rect x="370" y="110" width="110" height="70" fill="none" stroke="#E2504A" strokeWidth="2" />
          <line x1="150" y1="200" x2="650" y2="200" stroke="#E2504A" strokeWidth="3" strokeDasharray="12 8" />
        </svg>
      )
    },
    {
      code: 'CAM-03 // DOMESTIC PULSE',
      badge: '국내 여론 및 경제 충격 속보',
      badgeColor: 'bg-[#F2B134] text-[#0C1822]',
      speaker: simulationData?.news_article?.headline || '국내 긴급 여론 속보',
      headline: simulationData?.news_article?.body,
      visualDesc: simulationData?.news_article?.scene || '도심 대형 전광판 앞에서 긴급 뉴스를 지켜보는 시민들의 모습',
      bgOverlay: 'from-[#2e240d] via-[#1a1407] to-black',
      svgIcon: (
        <svg viewBox="0 0 800 320" className="w-full h-full object-cover opacity-60">
          <rect width="800" height="320" fill="#120f07" />
          <polyline points="100,240 220,210 310,250 430,140 540,180 680,90" fill="none" stroke="#F2B134" strokeWidth="4" />
          <circle cx="680" cy="90" r="8" fill="#F2B134" />
        </svg>
      )
    }
  ];

  const activeCut = scenes[Math.min(Math.max(sceneIdx - 1, 0), 2)];

  return (
    <div className="min-h-screen bg-[#070E14] text-[#E8EEF2] flex flex-col justify-between font-sans relative overflow-hidden select-none">
      {/* 상단 전술 방송 HUD */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-black/60 backdrop-blur z-30">
        <div className="flex items-center gap-3">
          <span className="font-black text-xl tracking-wider text-[#F2B134]">아르크24 TACTICAL</span>
          <span className="bg-[#E2504A] text-white text-[11px] font-bold px-2 py-0.5 rounded animate-pulse">ON AIR</span>
          <span className="text-xs text-slate-400 hidden sm:inline">국가: {countryName} | 선택 작전: {policy}</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const next = !muted;
              setMuted(next);
              if (!next) playRadioBeep();
            }}
            className="border border-white/20 bg-white/5 px-3 py-1.5 rounded-lg text-xs hover:border-[#F2B134] transition"
          >
            {muted ? '🔇 음소거 해제' : '🔊 전술 오디오 ON'}
          </button>

          {sceneIdx >= 4 && (
            <button
              onClick={onComplete}
              className="bg-[#F2B134] hover:bg-[#e0a024] text-[#0C1822] font-black px-5 py-2 rounded-lg text-sm transition shadow-lg animate-bounce"
            >
              윤리 관점 정책 검사하기 ➔
            </button>
          )}
        </div>
      </header>

      {/* 0~3초: 긴급 비상 사이렌 오버레이 */}
      {sceneIdx === 0 && (
        <div className="fixed inset-0 bg-[#2b0606]/95 z-50 flex flex-col items-center justify-center p-6 text-center">
          <div className="border-y-4 border-[#E2504A] py-8 px-6 max-w-2xl w-full bg-black/70 space-y-4 animate-pulse">
            <div className="text-xs font-mono tracking-[0.3em] text-[#E2504A]">EMERGENCY BROADCAST SYSTEM</div>
            <h1 className="text-4xl md:text-6xl font-black text-white tracking-tight">긴급 외교 사태 발령</h1>
            <p className="text-base md:text-lg text-slate-300">
              [{countryName}]의 “{policy}” 발표 직후 국제 정세가 요동치고 있습니다
            </p>
          </div>
        </div>
      )}

      {/* 시네마틱 컷신 뷰포트 (1~3단계 순차 재생 / 4단계 전체 컷신 선택 열람) */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 max-w-5xl mx-auto w-full z-20">
        <div className={`w-full rounded-3xl border border-white/15 bg-gradient-to-br ${activeCut.bgOverlay} shadow-2xl overflow-hidden transition-all duration-700`}>
          {/* 16:9 와이드 시네마틱 스크린 영역 */}
          <div className="relative w-full aspect-[16/7] bg-black/80 flex items-center justify-center overflow-hidden border-b border-white/10">
            {activeCut.svgIcon}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40" />

            <div className="absolute top-4 left-5 flex items-center gap-2">
              <span className={`text-xs font-black px-3 py-1 rounded ${activeCut.badgeColor}`}>
                {activeCut.badge}
              </span>
              <span className="text-[11px] font-mono text-white/60">{activeCut.code}</span>
            </div>

            <div className="absolute bottom-4 left-5 right-5 flex justify-between items-end">
              <p className="text-xs md:text-sm text-slate-300 bg-black/60 px-3 py-1.5 rounded-lg border border-white/10">
                🎥 현장 상황: {activeCut.visualDesc}
              </p>
              <span className="text-[10px] text-white/50 bg-black/70 px-2 py-1 rounded">AI 가상 시뮬레이션</span>
            </div>
          </div>

          {/* 게임 컷신 자막 스타일 브리핑 영역 */}
          <div className="p-6 md:p-8 space-y-3 bg-black/60">
            <div className="text-sm font-bold text-[#F2B134] tracking-wide">
              ▶ {activeCut.speaker}
            </div>
            <p className="text-lg md:text-2xl font-bold text-white leading-relaxed">
              “{activeCut.headline}”
            </p>
          </div>
        </div>

        {/* 18초 경과 후: 3장면 다시 보기 탭 및 다음 단계 안내 */}
        {sceneIdx >= 4 ? (
          <div className="mt-6 w-full flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/5 border border-white/10 p-4 rounded-2xl">
            <div className="flex gap-2">
              {['1. 동맹국 반응', '2. 교역국 보복', '3. 국내 여론'].map((label, i) => (
                <button
                  key={i}
                  onClick={() => { setSceneIdx(i + 1); setTimeout(() => setSceneIdx(4), 100); }}
                  className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold transition"
                >
                  {label} 다시보기
                </button>
              ))}
            </div>
            <button
              onClick={onComplete}
              className="w-full sm:w-auto px-6 py-3 bg-[#34B3A8] hover:bg-[#2a968c] text-[#0C1822] font-black rounded-xl text-sm shadow-lg"
            >
              시뮬레이션 종료 · 두 윤리 이론으로 정책 검증하기 ➔
            </button>
          </div>
        ) : (
          <div className="mt-4 flex items-center gap-2 text-xs text-slate-400">
            <span className="inline-block w-2 h-2 rounded-full bg-[#E2504A] animate-ping" />
            실시간 외교 파장 브리핑 수신 중... (잠시 후 정책 검증 단계로 넘어갑니다)
          </div>
        )}
      </main>

      {/* 하단 속보 티커 */}
      <footer className="bg-[#E2504A] text-white py-2 px-4 flex items-center gap-4 z-30">
        <span className="bg-white text-[#E2504A] font-black text-xs px-2.5 py-0.5 rounded shrink-0">속보</span>
        <div className="text-xs md:text-sm font-bold truncate">
          {(simulationData?.ticker || ['긴급 외교 속보 수신 중...']).join('   ///   ')}
        </div>
      </footer>
    </div>
  );
}