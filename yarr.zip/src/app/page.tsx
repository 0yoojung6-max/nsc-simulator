import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#F3F6F8] text-[#16212B] flex items-center justify-center p-6">
      <div className="max-w-xl w-full bg-white border border-slate-200 rounded-3xl p-8 shadow-xl text-center space-y-6">
        <div className="space-y-2">
          <span className="text-xs font-bold px-3 py-1 bg-[#1F3A5F]/10 text-[#1F3A5F] rounded-full">
            고등학교 2학년 한국사 · 현대사회의 윤리 융합 수업
          </span>
          <h1 className="text-3xl font-bold text-[#1F3A5F]">국가안보회의(NSC) 시뮬레이터</h1>
          <p className="text-sm text-[#5B6B78]">
            광해군의 외교와 오늘의 선택: 국익과 도덕적 의무 사이에서
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <Link
            href="/join"
            className="p-6 rounded-2xl bg-[#2FA6A0] hover:bg-[#258782] text-white font-bold text-lg shadow transition flex flex-col items-center gap-2"
          >
            <span>🎓 학생 모둠 입장</span>
            <span className="text-xs font-normal opacity-90">QR 또는 세션 코드로 참여</span>
          </Link>

          <Link
            href="/teacher"
            className="p-6 rounded-2xl bg-[#1F3A5F] hover:bg-[#2c4e7d] text-white font-bold text-lg shadow transition flex flex-col items-center gap-2"
          >
            <span>🧑‍🏫 교사 통제실</span>
            <span className="text-xs font-normal opacity-90">세션 생성 · 실시간 모니터링 · 발표 모드</span>
          </Link>
        </div>
      </div>
    </main>
  );
}