'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { db, ensureAnonAuth } from '@/app/lib/firebaseClient';
import { doc, onSnapshot } from 'firebase/firestore';
import { POLICIES, EMBLEM_COLORS, EMBLEM_SHAPES, WORLD_ACTORS, isBlockedCountryName } from '@/app/lib/constants';
import SimulationS4 from '@/components/SimulationS4';

function JoinContent() {
  const searchParams = useSearchParams();
  const urlCode = searchParams.get('code')?.toUpperCase() || '';

  const [sessionCode, setSessionCode] = useState(urlCode);
  const [groupId, setGroupId] = useState<number | null>(null);
  const [sessionData, setSessionData] = useState<any>(null);
  const [groupData, setGroupData] = useState<any>(null);
  const [allGroups, setAllGroups] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // S1 건국 입력
  const [countryName, setCountryName] = useState('');
  const [countryIntro, setCountryIntro] = useState('');
  const [emblemColor, setEmblemColor] = useState(EMBLEM_COLORS[0]);
  const [emblemShape, setEmblemShape] = useState(EMBLEM_SHAPES[0]);

  // S3 정책 결정
  const [selectedPolicy, setSelectedPolicy] = useState<string>(POLICIES[0].label);
  const [reason, setReason] = useState('');
  const [theoryLean, setTheoryLean] = useState<'결과와 국익 중심(공리주의)' | '원칙과 약속 중심(의무론)'>('결과와 국익 중심(공리주의)');

  // S3.6 최종 결정
  const [rebuttalReply, setRebuttalReply] = useState('');
  const [keepOrRevise, setKeepOrRevise] = useState<'유지' | '수정'>('유지');
  const [finalPolicy, setFinalPolicy] = useState('');
  const [finalReason, setFinalReason] = useState('');
  const [isBlackout, setIsBlackout] = useState(false);

  // S5 양 관점(공리주의 + 의무론) 교차 검증 상태
  const [utilCheck, setUtilCheck] = useState({
    citizens: '이익이 더 크다',
    world: '피해가 더 크다',
    verdict: '통과' as '통과' | '부적합',
    note: '',
  });
  const [deonCheck, setDeonCheck] = useState({
    promiseKept: '지켰다',
    universalRule: '모든 나라가 따라도 된다',
    verdict: '부적합' as '통과' | '부적합',
    note: '',
  });

  // S6 광해군 비교 상태
  const [compareDiffs, setCompareDiffs] = useState({ diff1: '', diff2: '', diff3: '' });

  useEffect(() => {
    if (!sessionCode) return;
    let unsubSession: any;
    let unsubGroups: any[] = [];

    ensureAnonAuth().then(() => {
      unsubSession = onSnapshot(doc(db, 'sessions', sessionCode), (snap) => {
        if (snap.exists()) setSessionData(snap.data());
      });

      for (let g = 1; g <= 4; g++) {
        const u = onSnapshot(doc(db, `sessions/${sessionCode}/groups/${g}`), (snap) => {
          if (snap.exists()) {
            setAllGroups((prev) => ({ ...prev, [String(g)]: snap.data() }));
            if (groupId === g) setGroupData(snap.data());
          }
        });
        unsubGroups.push(u);
      }
    });

    return () => {
      if (unsubSession) unsubSession();
      unsubGroups.forEach((u) => u());
    };
  }, [sessionCode, groupId]);

  useEffect(() => {
    if (sessionCode) {
      const savedGroup = localStorage.getItem(`nsc_group_${sessionCode}`);
      if (savedGroup) setGroupId(Number(savedGroup));
    }
  }, [sessionCode]);

  const callSessionApi = async (action: string, payload: any = {}, targetGroup = groupId) => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, code: sessionCode, groupId: targetGroup, payload }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || '요청 처리에 실패했습니다.');
      return data;
    } catch (e: any) {
      setErrorMsg(e.message);
      return null;
    } finally {
      setLoading(false);
    }
  };

  const handleJoinGroup = async (num: number) => {
    const res = await callSessionApi('JOIN_GROUP', {}, num);
    if (res?.success) {
      localStorage.setItem(`nsc_group_${sessionCode}`, String(num));
      setGroupId(num);
    }
  };

  const handleFoundCountry = async () => {
    if (isBlockedCountryName(countryName)) {
      return setErrorMsg('실제 국가명은 사용할 수 없습니다. 가상의 나라 이름을 지어 주세요.');
    }
    await callSessionApi('FOUND_COUNTRY', {
      name: countryName,
      intro: countryIntro,
      emblem: { color: emblemColor, shape: emblemShape },
    });
  };

  const handleRequestRebuttal = async () => {
    if (reason.trim().length < 20) {
      return setErrorMsg('우리 모둠의 선택 이유를 20자 이상 적어주세요.');
    }
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'GENERATE_REBUTTAL',
          code: sessionCode,
          groupId,
          payload: { policy: selectedPolicy, reason, theory: theoryLean },
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setFinalPolicy(selectedPolicy);
      setFinalReason(reason);
    } catch (e: any) {
      setErrorMsg(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRunSimulation = async () => {
    if (!rebuttalReply.trim()) return setErrorMsg('자문위원의 질문에 대한 우리 모둠의 답변을 한 줄 적어주세요.');
    setLoading(true);
    setErrorMsg('');
    setIsBlackout(true);

    try {
      const res = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'RUN_SIMULATION',
          code: sessionCode,
          groupId,
          payload: {
            rebuttalReply,
            keepOrRevise,
            finalPolicy: keepOrRevise === '수정' ? finalPolicy : groupData?.draft?.policy,
            finalReason: keepOrRevise === '수정' ? finalReason : groupData?.draft?.reason,
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
    } catch (e: any) {
      setErrorMsg(e.message);
      setIsBlackout(false);
    } finally {
      setLoading(false);
      setTimeout(() => setIsBlackout(false), 1000);
    }
  };

  const currentStep = !groupId ? 'S0' : groupData?.step || 'S1';

  if (isBlackout) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col items-center justify-center text-white">
        <p className="text-xl font-black tracking-widest text-[#F2B134] animate-pulse">
          [{groupData?.country?.name}] 국가안보회의 최종 명령 하달 중...
        </p>
      </div>
    );
  }

  if (currentStep === 'S4' && groupData?.simulation) {
    return (
      <SimulationS4
        countryName={groupData.country?.name || '우리나라'}
        policy={groupData.final?.policy || ''}
        simulationData={groupData.simulation}
        s4Control={sessionData?.s4Control}
        onComplete={() => callSessionApi('SET_STEP', { step: 'S5' })}
      />
    );
  }

  // 모둠 외교 노선 칭호 계산 (S6 최종 엔딩용)
  const getDiplomaticTitle = () => {
    const p = groupData?.final?.policy || '';
    if (p.includes('전면')) return '신의를 지키는 강경 동맹파';
    if (p.includes('인도적')) return '생명을 존중하는 인도주의 중재자';
    if (p.includes('중립')) return '광해군의 후예, 실리적 균형 외교관';
    return '자국 경제를 수호하는 현실주의 전략가';
  };

  return (
    <div className="min-h-screen bg-[#F3F6F8] text-[#16212B] flex flex-col">
      {/* 심플하고 깔끔한 상단 국가 HUD (불필요한 숫자 게이지 제거) */}
      {groupId && groupData?.country && (
        <header className="bg-white border-b border-slate-200 px-4 py-3 sticky top-0 z-30 shadow-sm">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow"
                style={{ backgroundColor: groupData.country.emblem?.color || '#1F3A5F' }}
              >
                {groupData.country.emblem?.shape?.split(' ')[0] || '🛡️'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-base text-[#1F3A5F]">{groupData.country.name}</span>
                  <span className="text-xs px-2.5 py-0.5 bg-[#1F3A5F]/10 text-[#1F3A5F] rounded-full font-bold">
                    {groupId}모둠
                  </span>
                </div>
                <p className="text-xs text-[#5B6B78]">{groupData.country.intro}</p>
              </div>
            </div>

            <div className="text-xs font-bold px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600">
              {currentStep === 'S2' && '1단계: 위기 상황 파악'}
              {currentStep === 'S3' && '2단계: 정책 선택'}
              {currentStep === 'S3.5' && '3단계: 자문위원 반론'}
              {(currentStep === 'S5' || currentStep === 'S5_WAIT') && '4단계: 윤리 관점 검증'}
              {(currentStep === 'S6' || currentStep === 'DONE') && '5단계: 역사와의 대화'}
            </div>
          </div>
        </header>
      )}

      <main className="flex-1 max-w-4xl w-full mx-auto p-6">
        {errorMsg && (
          <div className="mb-4 p-4 bg-red-50 border-l-4 border-[#D64545] text-[#D64545] text-sm font-bold rounded-r-xl">
            ⚠️ {errorMsg}
          </div>
        )}

        {/* S0: 모둠 선택 */}
        {currentStep === 'S0' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-xl space-y-6 mt-6">
            <div className="text-center space-y-2">
              <span className="text-xs font-bold px-3 py-1 bg-[#1F3A5F]/10 text-[#1F3A5F] rounded-full">
                역사 × 윤리 융합 시뮬레이션
              </span>
              <h1 className="text-2xl font-black text-[#1F3A5F]">국가안보회의(NSC) 모둠 입장</h1>
              <p className="text-sm text-[#5B6B78]">우리 모둠 번호를 선택해 회의실에 입장하세요.</p>
            </div>

            {!urlCode && (
              <div className="max-w-xs mx-auto">
                <input
                  type="text"
                  maxLength={6}
                  value={sessionCode}
                  onChange={(e) => setSessionCode(e.target.value.toUpperCase())}
                  placeholder="세션 코드 6자리"
                  className="w-full border-2 border-slate-200 rounded-xl p-3 text-center font-black tracking-widest uppercase"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((num) => {
                const isOccupied = allGroups[String(num)]?.occupied;
                return (
                  <button
                    key={num}
                    onClick={() => handleJoinGroup(num)}
                    disabled={loading || !sessionCode}
                    className={`p-6 rounded-2xl border-2 text-left transition ${
                      isOccupied
                        ? 'bg-slate-50 border-slate-200 text-slate-400'
                        : 'bg-white border-[#1F3A5F]/20 hover:border-[#1F3A5F] hover:shadow-md'
                    }`}
                  >
                    <div className="text-xl font-black text-[#1F3A5F]">{num}모둠</div>
                    <div className="text-xs mt-1 font-semibold">
                      {isOccupied ? '🔒 활동 중 (재입장 가능)' : '🟢 입장하기'}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* S1: 건국 */}
        {currentStep === 'S1' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            <div className="md:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 shadow-lg space-y-5">
              <div>
                <h2 className="text-xl font-black text-[#1F3A5F]">🏛️ 우리 모둠의 국가 세우기</h2>
                <p className="text-xs text-[#5B6B78] mt-1">실제 나라 이름(한국, 미국 등)을 제외한 멋진 가상 국가 이름을 지어주세요.</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold mb-1">국가 이름 (최대 8자)</label>
                  <input
                    type="text"
                    maxLength={8}
                    value={countryName}
                    onChange={(e) => setCountryName(e.target.value)}
                    placeholder="예: 마르디아, 한울국"
                    className="w-full border border-slate-300 rounded-xl p-3 text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-1">우리 나라의 핵심 가치 (한 줄 소개)</label>
                  <input
                    type="text"
                    maxLength={40}
                    value={countryIntro}
                    onChange={(e) => setCountryIntro(e.target.value)}
                    placeholder="예: 경제 번영과 평화를 중시하는 첨단 산업 국가"
                    className="w-full border border-slate-300 rounded-xl p-3 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">국기 상징 선택</label>
                  <div className="flex gap-2 mb-3">
                    {EMBLEM_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setEmblemColor(c)}
                        className={`w-8 h-8 rounded-full border-2 ${emblemColor === c ? 'border-black scale-110' : 'border-transparent'}`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {EMBLEM_SHAPES.map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setEmblemShape(s)}
                        className={`py-2 px-3 rounded-xl border text-xs font-bold ${
                          emblemShape === s ? 'bg-[#1F3A5F] text-white border-[#1F3A5F]' : 'bg-slate-50 border-slate-200'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleFoundCountry}
                  disabled={loading || !countryName.trim()}
                  className="w-full py-4 bg-[#2FA6A0] hover:bg-[#258782] text-white font-black rounded-xl transition shadow-md disabled:bg-slate-300"
                >
                  {loading ? '건국 선포 중...' : '🎖️ 건국 선포하고 외교 위기 확인하기'}
                </button>
              </div>
            </div>

            <div className="md:col-span-5 bg-white border-2 border-[#1F3A5F] rounded-3xl p-6 shadow-lg text-center space-y-4">
              <span className="text-xs font-bold text-[#2FA6A0]">건국 인증패 미리보기</span>
              <div
                className="w-24 h-24 mx-auto rounded-2xl flex items-center justify-center text-5xl text-white shadow-inner"
                style={{ backgroundColor: emblemColor }}
              >
                {emblemShape.split(' ')[0]}
              </div>
              <h3 className="text-2xl font-black text-[#1F3A5F]">{countryName || '국가 이름'}</h3>
              <p className="text-xs text-[#5B6B78]">{countryIntro || '우리 나라를 한 줄로 소개해 주세요.'}</p>
            </div>
          </div>
        )}

        {/* S2: 직관적인 현대 외교 위기 상황판 */}
        {currentStep === 'S2' && (
          <div className="space-y-6">
            <div className="bg-[#16212B] text-white rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <span className="bg-[#D64545] text-white text-xs font-black px-3 py-1 rounded-full animate-pulse">
                  🚨 긴급 안보 브리핑
                </span>
                <span className="text-xs text-slate-400">수신 국가: {groupData?.country?.name}</span>
              </div>

              <div className="space-y-2">
                <h2 className="text-xl md:text-2xl font-black text-[#F2B134]">
                  “동맹의 의리냐, 우리 경제의 생존이냐?”
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed">
                  이웃 민주주의 소국 <b className="text-white">자유항(프리포트)</b>이 거대 강대국 <b className="text-[#E2504A]">중원 인민공화국</b>에 의해 해상 봉쇄되었습니다. 우리 <b className="text-[#34B3A8]">{groupData?.country?.name}</b> 앞에 두 개의 상반된 최후통첩이 놓여 있습니다.
                </p>
              </div>

              {/* 3자 구도 시각화 카드 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white/5 border border-[#34B3A8]/40 rounded-2xl p-5 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-black text-[#34B3A8] text-base">🇺🇸 {WORLD_ACTORS.ally.name}</span>
                    <span className="text-[11px] bg-[#34B3A8]/20 text-[#34B3A8] px-2 py-0.5 rounded font-bold">우리의 안보 동맹국</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    “오랜 방위조약에 따라 자유항 방어를 위한 군사·물자 지원을 요청합니다. 동맹의 약속을 지켜주십시오.”
                  </p>
                </div>

                <div className="bg-white/5 border border-[#E2504A]/40 rounded-2xl p-5 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-black text-[#E2504A] text-base">🇨🇳 {WORLD_ACTORS.trade.name}</span>
                    <span className="text-[11px] bg-[#E2504A]/20 text-[#E2504A] px-2 py-0.5 rounded font-bold">우리 수출 40% 교역국</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    “자유항 사태에 개입하는 순간, 귀국 반도체·자동차 수입을 전면 금지하고 원자재 공급을 끊겠습니다.”
                  </p>
                </div>
              </div>

              <button
                onClick={() => callSessionApi('SET_STEP', { step: 'S3' })}
                className="w-full py-4 bg-[#F2B134] hover:bg-[#e0a024] text-[#16212B] font-black rounded-2xl transition shadow-lg text-base"
              >
                🏛️ 국가안보회의(NSC) 열고 우리 입장 정하기 ➔
              </button>
            </div>
          </div>
        )}

        {/* S3: 정책 결정 */}
        {currentStep === 'S3' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-lg space-y-6">
            <div>
              <h2 className="text-xl font-black text-[#1F3A5F]">⚖️ [{groupData?.country?.name}]의 외교 선택</h2>
              <p className="text-xs text-[#5B6B78] mt-1">4가지 선택지 중 하나를 고르고, 우리 모둠이 그렇게 결정한 핵심 이유를 적어주세요.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {POLICIES.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setSelectedPolicy(p.label)}
                  className={`p-4 rounded-2xl border-2 text-left transition ${
                    selectedPolicy === p.label
                      ? 'border-[#1F3A5F] bg-[#1F3A5F]/5 shadow-sm'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className="text-[11px] font-bold text-[#2FA6A0]">{p.tag}</span>
                  <div className="font-black text-base text-[#1F3A5F] mt-0.5">{p.label}</div>
                  <p className="text-xs text-[#5B6B78] mt-1 leading-relaxed">{p.desc}</p>
                </button>
              ))}
            </div>

            <div>
              <label className="block text-sm font-bold mb-1">우리 모둠이 이 길을 선택한 이유 (20자 이상)</label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={3}
                placeholder="예: 당장 경제가 흔들리더라도 동맹과의 약속과 자유항 시민들의 생명을 지키는 것이 옳다고 생각합니다."
                className="w-full border border-slate-300 rounded-xl p-3 text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">우리 모둠의 판단 기준은 어느 쪽에 더 가깝나요?</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { id: '결과와 국익 중심(공리주의)', desc: '우리 국민과 전체가 얻을 실질적 이익과 피해를 따짐' },
                  { id: '원칙과 약속 중심(의무론)', desc: '손해를 보더라도 지켜야 할 도덕적 의무와 신의를 따짐' },
                ].map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setTheoryLean(t.id as any)}
                    className={`p-3.5 rounded-xl border-2 text-left ${
                      theoryLean === t.id ? 'bg-[#2FA6A0]/10 border-[#2FA6A0]' : 'border-slate-200'
                    }`}
                  >
                    <div className="font-bold text-sm text-[#1F3A5F]">{t.id}</div>
                    <div className="text-xs text-[#5B6B78] mt-0.5">{t.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleRequestRebuttal}
              disabled={loading}
              className="w-full py-4 bg-[#1F3A5F] hover:bg-[#2a4d7d] text-white font-black rounded-2xl transition shadow"
            >
              {loading ? '외교 자문위원이 반론을 준비 중입니다...' : '결정 제출하고 자문위원 반론 듣기 ➔'}
            </button>
          </div>
        )}

        {/* S3.5 & S3.6: AI 반론 확인 및 최종 결정 */}
        {currentStep === 'S3.5' && groupData?.rebuttal && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-lg space-y-6">
            <div className="p-5 bg-amber-50 border-2 border-[#F2B134] rounded-2xl space-y-3">
              <span className="text-xs font-black px-3 py-1 bg-[#F2B134] text-[#16212B] rounded-full">
                💬 [{groupData?.country?.name}] 외교 자문위원의 반론
              </span>
              <p className="text-base font-medium leading-relaxed text-[#16212B]">{groupData.rebuttal.rebuttal}</p>
              <div className="p-4 bg-white rounded-xl border border-amber-200">
                <span className="text-xs font-black text-[#D64545]">❓ 자문위원의 돌직구 질문</span>
                <p className="text-sm font-bold mt-1 text-[#1F3A5F]">{groupData.rebuttal.question}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold mb-1">질문에 대한 우리 모둠의 반박 한 줄</label>
                <input
                  type="text"
                  value={rebuttalReply}
                  onChange={(e) => setRebuttalReply(e.target.value)}
                  placeholder="자문위원의 지적에 대해 우리 모둠의 입장을 한 줄로 답해보세요."
                  className="w-full border border-slate-300 rounded-xl p-3 text-sm"
                />
              </div>

              <div className="flex gap-3">
                {(['유지', '수정'] as const).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => {
                      setKeepOrRevise(opt);
                      if (opt === '수정') {
                        setFinalPolicy(groupData.draft?.policy || '');
                        setFinalReason(groupData.draft?.reason || '');
                      }
                    }}
                    className={`flex-1 py-3 rounded-xl border-2 font-bold text-sm ${
                      keepOrRevise === opt ? 'border-[#1F3A5F] bg-[#1F3A5F] text-white' : 'border-slate-200'
                    }`}
                  >
                    기존 정책 그대로 {opt}
                  </button>
                ))}
              </div>

              {keepOrRevise === '수정' && (
                <div className="p-4 bg-slate-50 rounded-xl border space-y-3">
                  <select
                    value={finalPolicy}
                    onChange={(e) => setFinalPolicy(e.target.value)}
                    className="w-full border rounded-lg p-2.5 text-sm bg-white font-bold"
                  >
                    {POLICIES.map((p) => (
                      <option key={p.id} value={p.label}>{p.label}</option>
                    ))}
                  </select>
                  <textarea
                    value={finalReason}
                    onChange={(e) => setFinalReason(e.target.value)}
                    rows={2}
                    className="w-full border rounded-lg p-2.5 text-sm bg-white"
                  />
                </div>
              )}

              <button
                onClick={handleRunSimulation}
                disabled={loading}
                className="w-full py-4 bg-[#D64545] hover:bg-[#b83737] text-white font-black rounded-2xl transition shadow-lg text-base"
              >
                {loading ? '시뮬레이션 가동 중...' : '🚨 최종 정책 발표 및 실시간 파장 확인하기'}
              </button>
            </div>
          </div>
        )}

        {/* S5: 공리주의 × 의무론 양 관점 교차 검증표 (단순화 및 통과/부적합 명확화) */}
        {(currentStep === 'S5' || currentStep === 'S5_WAIT') && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-lg space-y-6">
            <div className="border-b pb-4">
              <span className="text-xs font-black px-3 py-1 bg-[#1F3A5F]/10 text-[#1F3A5F] rounded-full">
                두 가지 윤리 렌즈로 교차 검증하기
              </span>
              <h2 className="text-xl font-black text-[#1F3A5F] mt-2">
                🔍 [{groupData?.country?.name}]의 “{groupData?.final?.policy}” 정책 검사
              </h2>
              <p className="text-xs text-[#5B6B78] mt-1">
                방금 본 시뮬레이션 결과를 바탕으로, 우리 선택이 <b>공리주의</b>와 <b>의무론</b> 기준을 각각 통과할 수 있는지 따져봅시다.
              </p>
            </div>

            {currentStep === 'S5_WAIT' ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border space-y-4">
                <div className="text-4xl">📊</div>
                <h3 className="text-lg font-black text-[#1F3A5F]">양 관점 윤리 검증 완료!</h3>
                <div className="flex justify-center gap-4 text-sm">
                  <span className="px-4 py-2 rounded-xl bg-white border font-bold">
                    공리주의 판정: <b className={groupData?.check?.utilVerdict === '통과' ? 'text-[#2FA6A0]' : 'text-[#D64545]'}>{groupData?.check?.utilVerdict}</b>
                  </span>
                  <span className="px-4 py-2 rounded-xl bg-white border font-bold">
                    의무론 판정: <b className={groupData?.check?.deonVerdict === '통과' ? 'text-[#2FA6A0]' : 'text-[#D64545]'}>{groupData?.check?.deonVerdict}</b>
                  </span>
                </div>
                {sessionData?.presenterGroup === groupId && (
                  <div className="p-4 bg-[#F2B134]/20 border-2 border-[#F2B134] rounded-xl font-black text-[#16212B] animate-bounce">
                    🎤 우리 모둠이 발표 모둠으로 선정되었습니다!
                  </div>
                )}
                <button
                  onClick={() => callSessionApi('SET_STEP', { step: 'S6' })}
                  className="mt-2 px-8 py-3.5 bg-[#1F3A5F] text-white text-sm font-black rounded-xl shadow"
                >
                  마지막 단계: 광해군과 비교 및 최종 리포트 ➔
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {/* 렌즈 1: 공리주의 검사 */}
                <div className="p-5 bg-blue-50/60 border border-blue-200 rounded-2xl space-y-3">
                  <div className="flex justify-between items-center">
                    <h3 className="font-black text-base text-[#1F3A5F]">렌즈 1. 공리주의 (결과가 가져온 이익 vs 피해)</h3>
                    <span className="text-xs text-blue-700 font-semibold">최대 다수의 최대 행복</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="font-bold block mb-1">1) 우리 국민에게 돌아온 결과는?</label>
                      <select
                        value={utilCheck.citizens}
                        onChange={(e) => setUtilCheck({ ...utilCheck, citizens: e.target.value })}
                        className="w-full border rounded-lg p-2 bg-white"
                      >
                        <option>이익이 더 크다 (경제·안전 확보)</option>
                        <option>피해가 더 크다 (물가 폭등·안보 불안)</option>
                      </select>
                    </div>
                    <div>
                      <label className="font-bold block mb-1">2) 자유항 시민과 국제사회 전체로 보면?</label>
                      <select
                        value={utilCheck.world}
                        onChange={(e) => setUtilCheck({ ...utilCheck, world: e.target.value })}
                        className="w-full border rounded-lg p-2 bg-white"
                      >
                        <option>이익이 더 크다 (평화·인명 구조)</option>
                        <option>피해가 더 크다 (전쟁 확산·고립)</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 pt-2">
                    <span className="text-xs font-bold">공리주의 기준 최종 판정:</span>
                    {(['통과', '부적합'] as const).map((v) => (
                      <button
                        key={v}
                        type="button"
                        onClick={() => setUtilCheck({ ...utilCheck, verdict: v })}
                        className={`px-4 py-1.5 rounded-lg text-xs font-black border ${
                          utilCheck.verdict === v
                            ? v === '통과' ? 'bg-[#2FA6A0] text-white border-[#2FA6A0]' : 'bg-[#D64545] text-white border-[#D64545]'
                            : 'bg-white text-slate-600'
                        }`}
                      >
                        {v}
                      </button>
                    ))}
                    <input
                      type="text"
                      value={utilCheck.note}
                      onChange={(e) => setUtilCheck({ ...utilCheck, note: e.target.value })}
                      placeholder="공리주의 판정 이유 한 줄"
                      className="flex-1 border rounded-lg px-3 py-1.5 text-xs bg-white"
                    />
                  </div>
                </div>

                {/* 렌즈 2: 의무론 검사 */}
                <div className="p-5 bg-emerald-50/60 border border-emerald-200 rounded-2xl space-y-3">
                  <div className="flex justify-between items-center">
                    <h3 className="font-black text-base text-[#1F3A5F]">렌즈 2. 의무론 (이익을 떠나 옳은 행동인가?)</h3>
                    <span className="text-xs text-emerald-700 font-semibold">약속 준수 · 보편적 도덕 법칙</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="font-bold block mb-1">1) 동맹국과의 조약·약속을 지켰는가?</label>
                      <select
                        value={deonCheck.promiseKept}
                        onChange={(e) => setDeonCheck({ ...deonCheck, promiseKept: e.target.value })}
                        className="w-full border rounded-lg p-2 bg-white"
                      >
                        <option>지켰다 (신의를 다함)</option>
                        <option>어겼다 (약속을 저버림)</option>
                      </select>
                    </div>
                    <div>
                      <label className="font-bold block mb-1">2) 세상의 모든 나라가 우리처럼 행동해도 괜찮은가?</label>
                      <select
                        value={deonCheck.universalRule}
                        onChange={(e) => setDeonCheck({ ...deonCheck, universalRule: e.target.value })}
                        className="w-full border rounded-lg p-2 bg-white"
                      >
                        <option>모든 나라가 따라도 된다</option>
                        <option>모두가 따르면 세상이 혼란해진다</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 pt-2">
                    <span className="text-xs font-bold">의무론 기준 최종 판정:</span>
                    {(['통과', '부적합'] as const).map((v) => (
                      <button
                        key={v}
                        type="button"
                        onClick={() => setDeonCheck({ ...deonCheck, verdict: v })}
                        className={`px-4 py-1.5 rounded-lg text-xs font-black border ${
                          deonCheck.verdict === v
                            ? v === '통과' ? 'bg-[#2FA6A0] text-white border-[#2FA6A0]' : 'bg-[#D64545] text-white border-[#D64545]'
                            : 'bg-white text-slate-600'
                        }`}
                      >
                        {v}
                      </button>
                    ))}
                    <input
                      type="text"
                      value={deonCheck.note}
                      onChange={(e) => setDeonCheck({ ...deonCheck, note: e.target.value })}
                      placeholder="의무론 판정 이유 한 줄"
                      className="flex-1 border rounded-lg px-3 py-1.5 text-xs bg-white"
                    />
                  </div>
                </div>

                <button
                  onClick={() =>
                    callSessionApi('SUBMIT_CHECK', {
                      check: {
                        utilVerdict: utilCheck.verdict,
                        utilNote: utilCheck.note,
                        deonVerdict: deonCheck.verdict,
                        deonNote: deonCheck.note,
                      },
                    })
                  }
                  disabled={loading || !utilCheck.note.trim() || !deonCheck.note.trim()}
                  className="w-full py-4 bg-[#1F3A5F] text-white font-black rounded-2xl shadow-lg"
                >
                  양 관점 검사 결과 제출하기
                </button>
              </div>
            )}
          </div>
        )}

        {/* S6: 광해군과 비교 및 의미 있는 게임 엔딩 크레딧 */}
        {(currentStep === 'S6' || currentStep === 'DONE') && (
          <div className="space-y-6">
            {currentStep === 'DONE' ? (
              <div className="bg-[#16212B] text-white rounded-3xl p-8 shadow-2xl space-y-6 border-2 border-[#F2B134]">
                <div className="text-center space-y-2 border-b border-white/10 pb-6">
                  <span className="text-xs font-black px-3 py-1 bg-[#F2B134] text-[#16212B] rounded-full">
                    FINAL DIPLOMATIC REPORT
                  </span>
                  <h2 className="text-2xl md:text-3xl font-black text-white mt-2">
                    [{groupData?.country?.name}] 외교 시뮬레이션 최종 성적표
                  </h2>
                  <p className="text-lg font-bold text-[#34B3A8]">
                    칭호: “{getDiplomaticTitle()}”
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-1">
                    <span className="text-xs text-slate-400">우리의 최종 선택</span>
                    <div className="font-black text-lg text-[#F2B134]">{groupData?.final?.policy}</div>
                    <p className="text-xs text-slate-300 mt-1">{groupData?.final?.reason}</p>
                  </div>

                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-2">
                    <span className="text-xs text-slate-400">윤리적 딜레마 교차 판정</span>
                    <div className="flex justify-between text-xs font-bold">
                      <span>공리주의(이익·결과):</span>
                      <span className={groupData?.check?.utilVerdict === '통과' ? 'text-[#34B3A8]' : 'text-[#E2504A]'}>
                        {groupData?.check?.utilVerdict} ({groupData?.check?.utilNote})
                      </span>
                    </div>
                    <div className="flex justify-between text-xs font-bold">
                      <span>의무론(원칙·약속):</span>
                      <span className={groupData?.check?.deonVerdict === '통과' ? 'text-[#34B3A8]' : 'text-[#E2504A]'}>
                        {groupData?.check?.deonVerdict} ({groupData?.check?.deonNote})
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-[#F2B134]/10 border border-[#F2B134]/40 p-5 rounded-2xl space-y-2">
                  <h4 className="font-black text-sm text-[#F2B134]">💡 오늘 활동의 핵심 통찰</h4>
                  <p className="text-xs md:text-sm text-slate-200 leading-relaxed">
                    1619년 사르후 전투 당시 <b>광해군</b> 역시 명나라의 파병 요구(의무론적 신의)와 후금의 위협(공리주의적 국익) 사이에서 고뇌했습니다. 오늘 여러분의 선택처럼 <b>공리주의를 통과하면 의무론에 걸리고, 의무론을 지키면 공리주의적 피해가 발생하는 딜레마</b>는 오늘날 외교 현장에서도 여전히 계속되고 있습니다.
                  </p>
                </div>

                <div className="text-center text-xs text-slate-400 pt-2">
                  ※ 이제 배부된 학습지 마지막 칸에 <b>“국익과 도덕적 의무가 부딪힐 때 나는 무엇을 기준으로 선택할 것인가?”</b>에 대한 나의 생각을 한 문장으로 정리해 주세요.
                </div>
              </div>
            ) : (
              <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-lg space-y-6">
                <div>
                  <h2 className="text-xl font-black text-[#1F3A5F]">📜 17세기 광해군의 선택과 오늘 우리의 선택 비교</h2>
                  <p className="text-xs text-[#5B6B78] mt-1">명·후금 사이에서 고민한 광해군과 오늘 우리 국가의 상황을 비교해 봅시다.</p>
                </div>

                <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-1.5">
                  <h4 className="font-black text-sm text-[#1F3A5F]">공통점 (변하지 않는 외교의 딜레마)</h4>
                  <ul className="list-disc list-inside text-xs text-slate-700 space-y-1">
                    <li>강대국(명·후금 / 아메리카나·중원 공화국) 사이에서 국가의 생존을 걸고 선택해야 했다.</li>
                    <li>동맹의 의리(명분)와 백성의 안위(실리)가 정면으로 충돌했다.</li>
                  </ul>
                </div>

                <div className="space-y-3">
                  <h4 className="font-black text-sm text-[#1F3A5F]">차이점 (광해군 시대와 오늘날이 달라진 점 3가지)</h4>
                  <div>
                    <label className="block text-xs font-bold mb-1">1. 국제법과 조약의 구속력</label>
                    <input
                      type="text"
                      value={compareDiffs.diff1}
                      onChange={(e) => setCompareDiffs({ ...compareDiffs, diff1: e.target.value })}
                      placeholder="예: 군신 관계의 사대 명분에서 국제법과 상호방위조약 중심으로 달라졌다."
                      className="w-full border rounded-xl p-3 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold mb-1">2. 국제기구와 세계 여론의 역할</label>
                    <input
                      type="text"
                      value={compareDiffs.diff2}
                      onChange={(e) => setCompareDiffs({ ...compareDiffs, diff2: e.target.value })}
                      placeholder="예: UN 같은 국제기구와 실시간 언론 보도가 각국의 행동에 큰 압박을 준다."
                      className="w-full border rounded-xl p-3 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold mb-1">3. 국내 여론(백성 vs 시민)의 영향력</label>
                    <input
                      type="text"
                      value={compareDiffs.diff3}
                      onChange={(e) => setCompareDiffs({ ...compareDiffs, diff3: e.target.value })}
                      placeholder="예: 소수 신하들의 상소에서 벗어나 국민 전체의 여론과 경제적 타격이 즉각 반영된다."
                      className="w-full border rounded-xl p-3 text-sm"
                    />
                  </div>
                </div>

                <button
                  onClick={() => callSessionApi('SUBMIT_COMPARE', { compare: compareDiffs })}
                  disabled={loading || !compareDiffs.diff1.trim() || !compareDiffs.diff2.trim() || !compareDiffs.diff3.trim()}
                  className="w-full py-4 bg-[#2FA6A0] hover:bg-[#258782] text-white font-black rounded-2xl shadow-lg text-base"
                >
                  비교 완료 및 우리 국가 최종 성적표 확인하기 🏆
                </button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default function JoinPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center font-bold">시뮬레이터 로딩 중...</div>}>
      <JoinContent />
    </Suspense>
  );
}