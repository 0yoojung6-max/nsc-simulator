'use client';

import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { db, ensureAnonAuth } from '@/app/lib/firebaseClient';
import { doc, onSnapshot } from 'firebase/firestore';
import { FALLBACK_REBUTTALS, FALLBACK_SIMULATIONS } from '@/app/lib/constants';

export default function TeacherPage() {
  const [passcode, setPasscode] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [sessionCode, setSessionCode] = useState('');
  const [sessionData, setSessionData] = useState<any>(null);
  const [groups, setGroups] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const [showLargeQR, setShowLargeQR] = useState(false);
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'VERDICTS' | 'LOGS'>('DASHBOARD');
  const [originUrl, setOriginUrl] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') setOriginUrl(window.location.origin);
  }, []);

  useEffect(() => {
    if (!sessionCode || !isAuthenticated) return;
    let unsubSession: any;
    let unsubGroups: any[] = [];

    ensureAnonAuth().then(() => {
      unsubSession = onSnapshot(doc(db, 'sessions', sessionCode), (snap) => {
        if (snap.exists()) setSessionData(snap.data());
      });

      for (let g = 1; g <= 4; g++) {
        const u = onSnapshot(doc(db, `sessions/${sessionCode}/groups/${g}`), (snap) => {
          if (snap.exists()) setGroups((prev) => ({ ...prev, [String(g)]: snap.data() }));
        });
        unsubGroups.push(u);
      }
    });

    return () => {
      if (unsubSession) unsubSession();
      unsubGroups.forEach((u) => u());
    };
  }, [sessionCode, isAuthenticated]);

  const handleCreateSession = async () => {
    if (!passcode.trim()) return setErrorMsg('교사 비밀번호를 입력하세요.');
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'CREATE_SESSION', payload: { passcode } }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setSessionCode(data.code);
      setIsAuthenticated(true);
    } catch (e: any) {
      setErrorMsg(e.message);
    } finally {
      setLoading(false);
    }
  };

  const teacherUpdate = async (sessionUpdates: any = null, targetGroupId: number | null = null, groupUpdates: any = null) => {
    try {
      await fetch('/api/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'TEACHER_UPDATE',
          code: sessionCode,
          payload: { passcode, sessionUpdates, targetGroupId, groupUpdates },
        }),
      });
    } catch (e) {
      console.error(e);
    }
  };

  const handleSeedDemoData = async () => {
    setLoading(true);
    const demoPresets = [
      {
        id: 1,
        name: '마르디아',
        intro: '신의를 지키는 해양 동맹국',
        color: '#1F3A5F',
        shape: '🛡️ 방패',
        policy: '군사·물자 전면 지원',
        reason: '오랜 동맹국 아메리카나 연방과의 약속을 지키는 것이 국가의 도덕적 의무입니다.',
        utilVerdict: '부적합',
        utilNote: '중원 공화국의 수출 금지로 우리 국민의 경제 피해가 너무 큼',
        deonVerdict: '통과',
        deonNote: '손해를 감수하고서라도 동맹의 약속과 신의를 지켰음',
      },
      {
        id: 2,
        name: '한울공화국',
        intro: '평화와 실리의 균형 외교국',
        color: '#2FA6A0',
        shape: '🕊️ 비둘기',
        policy: '중립 선언 및 평화 중재',
        reason: '양 강대국 사이에서 우리 경제를 지키고 평화 중재에 나서는 것이 최선입니다.',
        utilVerdict: '통과',
        utilNote: '무역 보복을 피하고 국민의 안전과 경제를 지켜냄',
        deonVerdict: '부적합',
        deonNote: '위기에 처한 동맹국과의 방위조약 의무를 외면함',
      },
      {
        id: 3,
        name: '솔라리스',
        intro: '생명과 인권을 중시하는 나라',
        color: '#F2B134',
        shape: '⚖️ 천칭',
        policy: '식량·의료 인도적 지원',
        reason: '무기 지원은 피하되 굶주리는 자유항 민간인을 돕는 것이 인도주의 원칙입니다.',
        utilVerdict: '통과',
        utilNote: '전면전 휘말림은 피하면서 민간인 생명을 살림',
        deonVerdict: '통과',
        deonNote: '인간을 수단으로 대하지 않고 인도적 의무를 실천함',
      },
      {
        id: 4,
        name: '노르드연방',
        intro: '자국 경제 최우선 산업 강국',
        color: '#D64545',
        shape: '🧭 나침반',
        policy: '지원 거절 및 교역 유지',
        reason: '타국의 전쟁에 끼어들어 우리 기업과 일자리를 잃을 수는 없습니다.',
        utilVerdict: '통과',
        utilNote: '국내 기업 수출 확대와 경제 성장 극대화',
        deonVerdict: '부적합',
        deonNote: '자국 이익만 따지며 동맹과 약소국을 외면함',
      },
    ];

    for (const d of demoPresets) {
      const sim = FALLBACK_SIMULATIONS[d.policy];
      const reb = FALLBACK_REBUTTALS[d.policy];
      await teacherUpdate(null, d.id, {
        occupied: true,
        step: 'S5_WAIT',
        country: { name: d.name, intro: d.intro, emblem: { color: d.color, shape: d.shape } },
        draft: { policy: d.policy, reason: d.reason, theory: '양 관점 검토' },
        rebuttal: reb,
        rebuttalReply: '우리 모둠이 중시하는 가치를 지키기 위해 원안을 유지합니다.',
        final: { policy: d.policy, reason: d.reason, keepOrRevise: '유지' },
        simulation: sim,
        check: {
          utilVerdict: d.utilVerdict,
          utilNote: d.utilNote,
          deonVerdict: d.deonVerdict,
          deonNote: d.deonNote,
        },
      });
    }
    setLoading(false);
    alert('개편된 시나리오 기반 4개 모둠 데이터가 채워졌습니다!');
  };

  const joinUrl = `${originUrl}/join?code=${sessionCode}`;
  const presenterGroupNum = sessionData?.presenterGroup;
  const presenterData = presenterGroupNum ? groups[String(presenterGroupNum)] : null;

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen bg-[#F3F6F8] flex items-center justify-center p-6 text-[#16212B]">
        <div className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-8 shadow-xl space-y-6">
          <div className="text-center space-y-2">
            <span className="text-xs font-black px-3 py-1 bg-[#1F3A5F]/10 text-[#1F3A5F] rounded-full">교사 통제실</span>
            <h1 className="text-2xl font-black text-[#1F3A5F]">NSC 외교 시뮬레이터 관리</h1>
          </div>
          {errorMsg && <div className="p-3 bg-red-50 text-[#D64545] text-xs font-bold rounded-lg">{errorMsg}</div>}
          <input
            type="password"
            value={passcode}
            onChange={(e) => setPasscode(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleCreateSession()}
            placeholder="비밀번호 (1234)"
            className="w-full border border-slate-300 rounded-xl p-3.5 text-center font-black tracking-widest"
          />
          <button onClick={handleCreateSession} disabled={loading} className="w-full py-4 bg-[#1F3A5F] text-white font-black rounded-xl">
            {loading ? '세션 여는 중...' : '🚀 수업 세션 시작하기'}
          </button>
        </div>
      </main>
    );
  }

  if (presenterGroupNum && presenterData) {
    return (
      <div className="min-h-screen bg-[#16212B] text-white p-8 flex flex-col justify-center">
        <div className="max-w-5xl mx-auto w-full space-y-6">
          <div className="flex justify-between items-center border-b border-white/15 pb-4">
            <div className="flex items-center gap-4">
              <span className="bg-[#F2B134] text-[#16212B] font-black px-4 py-1.5 rounded-full text-sm">
                발표 모둠: {presenterGroupNum}모둠
              </span>
              <h1 className="text-3xl font-black">{presenterData.country?.name}</h1>
            </div>
            <button onClick={() => teacherUpdate({ presenterGroup: null })} className="bg-white/10 px-4 py-2 rounded-xl text-sm font-bold">
              ✕ 발표 모드 닫기
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/5 border border-white/10 rounded-3xl p-6 space-y-3">
              <span className="text-xs text-[#F2B134] font-bold">최종 외교 선택</span>
              <div className="text-2xl font-black">{presenterData.final?.policy}</div>
              <p className="text-sm text-slate-300 leading-relaxed bg-black/30 p-4 rounded-2xl">{presenterData.final?.reason}</p>
            </div>

            <div className="bg-white text-[#16212B] rounded-3xl p-6 space-y-4 shadow-2xl">
              <h3 className="font-black text-lg text-[#1F3A5F]">양 관점 윤리 교차 판정 결과</h3>
              <div className="p-4 bg-blue-50 rounded-2xl border border-blue-200 space-y-1">
                <div className="flex justify-between font-black text-sm">
                  <span>1. 공리주의 (결과·국익)</span>
                  <span className={presenterData.check?.utilVerdict === '통과' ? 'text-[#2FA6A0]' : 'text-[#D64545]'}>
                    {presenterData.check?.utilVerdict || '-'}
                  </span>
                </div>
                <p className="text-xs text-slate-700">{presenterData.check?.utilNote}</p>
              </div>
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-1">
                <div className="flex justify-between font-black text-sm">
                  <span>2. 의무론 (원칙·약속)</span>
                  <span className={presenterData.check?.deonVerdict === '통과' ? 'text-[#2FA6A0]' : 'text-[#D64545]'}>
                    {presenterData.check?.deonVerdict || '-'}
                  </span>
                </div>
                <p className="text-xs text-slate-700">{presenterData.check?.deonNote}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F3F6F8] text-[#16212B]">
      <header className="bg-[#1F3A5F] text-white px-6 py-4 shadow">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-black">NSC 시뮬레이터 교사 통제실</h1>
            <span className="bg-[#F2B134] text-[#16212B] font-black px-3 py-1 rounded-lg text-sm tracking-widest">
              코드: {sessionCode}
            </span>
            <button onClick={() => setShowLargeQR(true)} className="bg-white/15 px-3 py-1 rounded-lg text-xs font-bold">
              📱 QR 크게 보기
            </button>
          </div>
          <button onClick={handleSeedDemoData} disabled={loading} className="bg-[#2FA6A0] text-white px-4 py-2 rounded-lg text-xs font-black shadow">
            ⚡ 15분 실연용 가상 데이터 채우기
          </button>
        </div>
      </header>

      <div className="bg-white border-b border-slate-200 px-6">
        <div className="max-w-7xl mx-auto flex gap-6 text-sm font-black">
          {[
            { id: 'DASHBOARD', label: '1. 실시간 모둠 현황' },
            { id: 'VERDICTS', label: '2. 공리주의 × 의무론 교차 판정표' },
            { id: 'LOGS', label: '3. 자문위원 반론 및 논거 로그' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`py-3.5 border-b-2 ${activeTab === t.id ? 'border-[#1F3A5F] text-[#1F3A5F]' : 'border-transparent text-slate-400'}`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <main className="max-w-7xl mx-auto p-6 space-y-6">
        {activeTab === 'DASHBOARD' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {[1, 2, 3, 4].map((num) => {
              const g = groups[String(num)] || {};
              return (
                <div key={num} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-black text-lg text-[#1F3A5F]">{num}모둠</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${g.occupied ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-400'}`}>
                        {g.occupied ? `접속 중 (${g.step})` : '대기 중'}
                      </span>
                    </div>
                    <div className="text-base font-black text-slate-800">{g.country?.name || '미건국'}</div>
                    <div className="p-3 bg-slate-50 rounded-xl text-xs space-y-1">
                      <div>최종 선택: <b className="text-[#1F3A5F]">{g.final?.policy || '-'}</b></div>
                    </div>
                  </div>
                  <div className="pt-3 border-t flex gap-1.5">
                    <button onClick={() => teacherUpdate({ presenterGroup: num })} className="flex-1 py-2 bg-[#1F3A5F] text-white text-xs font-bold rounded-lg">
                      🎤 발표 띄우기
                    </button>
                    <button
                      onClick={() => teacherUpdate(null, num, { step: 'S1', occupied: false, country: null, draft: null, final: null, check: null })}
                      className="px-2.5 py-2 bg-red-50 text-[#D64545] text-xs font-bold rounded-lg"
                    >
                      초기화
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === 'VERDICTS' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
            <h2 className="text-lg font-black text-[#1F3A5F]">📊 모둠별 [공리주의 vs 의무론] 교차 판정 비교</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((num) => {
                const g = groups[String(num)] || {};
                const chk = g.check;
                return (
                  <div key={num} className="p-5 rounded-2xl border border-slate-200 bg-[#F3F6F8]/60 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="font-black text-base text-[#1F3A5F]">{num}모둠 ({g.country?.name || '미정'})</span>
                      <span className="text-xs font-bold px-2.5 py-1 bg-white border rounded-full">{g.final?.policy || '미제출'}</span>
                    </div>
                    {chk ? (
                      <div className="space-y-2 text-xs">
                        <div className="p-2.5 bg-white rounded-xl border flex justify-between items-center">
                          <span><b>공리주의:</b> {chk.utilNote}</span>
                          <span className={`font-black px-2 py-0.5 rounded text-white ${chk.utilVerdict === '통과' ? 'bg-[#2FA6A0]' : 'bg-[#D64545]'}`}>
                            {chk.utilVerdict}
                          </span>
                        </div>
                        <div className="p-2.5 bg-white rounded-xl border flex justify-between items-center">
                          <span><b>의무론:</b> {chk.deonNote}</span>
                          <span className={`font-black px-2 py-0.5 rounded text-white ${chk.deonVerdict === '통과' ? 'bg-[#2FA6A0]' : 'bg-[#D64545]'}`}>
                            {chk.deonVerdict}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-400">검증 결과 대기 중</div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'LOGS' && (
          <div className="space-y-4">
            {[1, 2, 3, 4].map((num) => {
              const g = groups[String(num)] || {};
              return (
                <div key={num} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-2 text-xs">
                  <div className="font-black text-sm text-[#1F3A5F]">{num}모둠 ({g.country?.name || '-'})</div>
                  <p><b>초기 선택 및 이유:</b> {g.draft?.policy} — {g.draft?.reason}</p>
                  <p className="text-amber-800"><b>자문위원 반론:</b> {g.rebuttal?.rebuttal}</p>
                  <p className="text-emerald-800"><b>학생 재반박:</b> {g.rebuttalReply}</p>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {showLargeQR && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-6" onClick={() => setShowLargeQR(false)}>
          <div className="bg-white rounded-3xl p-8 max-w-md w-full text-center space-y-5" onClick={(e) => e.stopPropagation()}>
            <h2 className="text-2xl font-black text-[#1F3A5F]">모둠 기기 QR 코드 입장</h2>
            <div className="flex justify-center p-4 bg-white border-2 border-slate-100 rounded-2xl">
              <QRCodeSVG value={joinUrl} size={240} />
            </div>
            <div className="text-2xl font-black text-[#1F3A5F] tracking-widest">세션 코드: {sessionCode}</div>
            <button onClick={() => setShowLargeQR(false)} className="w-full py-3 bg-[#1F3A5F] text-white font-bold rounded-xl">
              닫기
            </button>
          </div>
        </div>
      )}
    </div>
  );
}